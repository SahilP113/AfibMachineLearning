function seqlen = get_consecutive(signal)
%Vignesh Kalidas 
%PhD - Computer Engineering, 
%Dept of Electrical Engineering, 
%University of Texas at Dallas, Texas, USA
% GNU General public License
if size(signal,2) == 1
    signal = signal';
end
signal = diff(signal);
diffpts = diff(find(diff(signal)==0));
seqpts = find([diffpts inf]>= 1);
seqlen = diff([0 seqpts]) + 1;



