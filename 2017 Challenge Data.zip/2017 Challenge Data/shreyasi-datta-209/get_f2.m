function[FEATURES]= get_f2(signal_curr,Fs)
% Sibylle Fallet
% Sasan Yazdani
% Jean-Marc Vesin
% GNU GEneral public License
signal_curr=signal_curr-mean(signal_curr);
ecg1=signal_curr/max(signal_curr);
[R_inds,Q_inds,S_inds,QRS_On_II,QRS_Off_II,ecg_hat,Peak_activities]=F2AMM3(ecg1,Fs,1,1);
RR1=diff(R_inds)/Fs;
RR1_max=max(RR1);
FEATURES =RR1_max;
if isempty(FEATURES)
    FEATURES = 0;
end
end