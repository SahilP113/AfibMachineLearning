function [all_f] = generate_30_features(TS,Fs)
%
% Copyright (C) 2017
% Shreyasi Datta
% Chetanya Puri
% Ayan Mukherjee
% Rohan Banerjee
% Anirban Dutta Choudhury
% Arijit Ukil
% Soma Bandyopadhyay
% Rituraj Singh
% Arpan Pal
% Sundeep Khandelwal
%
% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; either version 2
% of the License, or (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

ecg_data=resample(TS,250,Fs);
Fs=250;
% Rank 2
try
    [f1] = get_fv(ecg_data,Fs); %2
    if(isempty(f1))
        f1=zeros(1,2);
    end
catch
    f1=zeros(1,2);
end
% keyboard;
try
    [f2] = get_fv1(ecg_data,Fs); %1*10 Feature : 12
    if(isempty(f2))
        f2=zeros(1,10);
    end
catch
    f2=zeros(1,10);
end
try
    [f4] = get_fv5(ecg_data,Fs); %13
    if(isempty(f4))
        f4=0;
    end
catch
    f4 = 0;
end

try
    [f5] = get_fv4(ecg_data,Fs); %14
    if(isempty(f5))
        f5=0;
    end
catch
    f5=0;
end

%Rank 4
try
    [f6]= get_f1(ecg_data,Fs); %16
    if(isempty(f6))
        f6=zeros(1,2);
    end
catch
    f6=zeros(1,2);
end

try
    [f7]= get_f2(ecg_data,Fs);%17
    if(isempty(f7))
        f7=0;
    end
catch
    f7=0;
end
% Rank 6

try
    [f9, f10,peaks1,ecg1,fs] = ecgSqiFeatures(ecg_data,Fs); % 6 Features %25
    if(isempty(f9))
        f9=zeros(1,6);
    end
    if(isempty(f10))
        f10=0;
    end
catch
    f9=zeros(1,6);
    f10=0;
end

try
    [f11] = hrFeatures(length(ecg1),peaks1,length(ecg1),fs, 0);%31
    if(isempty(f11))
        f11=zeros(1,6);
    end
catch
    f11=zeros(1,6);
end
all_f =[f1 f2 f4 f5 f6 f7 f9 f10 f11];
end
